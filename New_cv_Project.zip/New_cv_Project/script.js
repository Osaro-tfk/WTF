// User names
function Fullname() {
    var userFirstName = document.getElementById('firstName');
    var userLastName = document.getElementById('lastName');

// userFirstName.innerText 
    var anything = document.getElementById('firstNameInput')
    
}


